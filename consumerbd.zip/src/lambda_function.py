import boto3
import json
import base64
from decimal import Decimal
import datetime

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            return str(o)
        return super(DecimalEncoder, self).default(o)
        

dynamodb = boto3.resource('dynamodb')
table_name = 'dtable1'
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    # Specify your Kinesis Data Stream name
    stream_name = 'topic123'

    # Create a Kinesis client
    kinesis_client = boto3.client('kinesis')
    
    # Iterate through Kinesis records in the event
    for record in event['Records']:
        # Print the raw data before attempting to parse
        base64_data = record['kinesis']['data']
        raw_data = base64.b64decode(base64_data).decode('utf-8')

        print(f"Raw Kinesis Data: {raw_data}")

        try:
            # Attempt to parse the payload
            payload = json.loads(raw_data)

            # Extract relevant data from the payload
            item_id = payload['id']
            value = payload['value'] # Convert to Decimal
            timestamp = payload['email']

            # Put data into DynamoDB table
            response = table.put_item(
                Item={
                    'id': item_id,
                    'value': value,
                    'email': timestamp
                    }
            )

            print(f"Record with id {item_id} loaded into DynamoDB table {table_name}")
            
            
            
            # Specify your SNS topic ARN
            #sns_topic_arn = 'arn:aws:sns:ap-south-1:430006376054:kinesistopicsns'


            
            # Specify your SNS topic ARn
            #sns_topic_arn = 'arn:aws:sns:ap-south-1:430006376054:sns2307'
            
            # Create an SNS client
            #sns_client = boto3.client('sns')
            
              
            # Convert the data to JSON using the custom DecimalEncoder
            #message_body = json.dumps(message_data)
            
            # message_data = {
            #         'id': item_id,
            #         'value': value,
            #         'email': timestamp
            #         }
            
            # message_body = json.dumps(message_data)
             
            # response = sns_client.publish(
            #     TopicArn=sns_topic_arn,
            #     Message=message_body,
            #     Subject='Example Subject'  # Optional subject for the message
            #  )
            
            

            # print(f"Message sent to SNS topic {sns_topic_arn} with MessageId: {response['MessageId']}")



        except json.JSONDecodeError as e:
            # Handle JSON decoding error
            print(f"Error decoding JSON: {e}")
            continue  # Move on to the next record

    return {
        'statusCode': 200,
        'body': json.dumps('Data loaded into DynamoDB and SNS successfully!')
    }