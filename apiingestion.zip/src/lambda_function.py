import json
import requests
import boto3
import os
from datetime import datetime
from botocore.exceptions import ClientError


def lambda_handler(event, context):
    # TODO implement
    # Define the API endpoint URL
    url = "https://jsonplaceholder.typicode.com/users"
    
    #print(os.environ.get('apikey'))
    #pwd = os.environ.get('apipwd')
    print(os.environ.get('userkey'))
    pwd = os.environ.get('userpwd')
    print(pwd)
    
    # Send a GET request to the API
    response = requests.get(url)
    
    # Parse the JSON data from the response
    data = response.json()
    
    cilent = boto3.client('s3')

    
    filename = "mypro_raw_" + str(datetime.now()) + ".json"
    
    cilent.put_object(
        Bucket="bd-project",
        Key="rawbronze/toprocess/" + filename,
        Body=json.dumps(data)
        )
    
    # write code to move "rawbronze/toprocess to rawbronzr/processed
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

