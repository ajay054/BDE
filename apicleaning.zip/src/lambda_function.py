import json
import boto3
from datetime import datetime
from io import StringIO
import pandas as pd

def lambda_handler(event, context):
    # Initialize S3 client
    s3 = boto3.client('s3')
    Bucket = "bd-project"
    Key = "rawbronze/toprocess/"

    data1 = []
    keys = []

    # Loop through objects in S3 bucket
    for file in s3.list_objects(Bucket=Bucket, Prefix=Key)['Contents']:
        file_key = file['Key']
        if file_key.split('.')[-1] == "json":
            response = s3.get_object(Bucket=Bucket, Key=file_key)
            content = response['Body']
            jsonObject = json.loads(content.read())
            data1.append(jsonObject)
            keys.append(file_key)
    
    transformed_data = []

    # Transform the data
    for record in data1:
        for r in record:
            transformed_record = {
                'id': r['id'],
                'name': r['name'],
                'username': r['username'],
                'email': r['email'],
                'address': r['address']['street'] + ', ' + r['address']['city'] + ', ' + r['address']['zipcode']
            }
            transformed_data.append(transformed_record)

    # Convert to DataFrame and save to CSV
    user_df = pd.DataFrame.from_dict(transformed_data)
    user_key = "stagingsilver/user_transformed_" + str(datetime.now()) + ".csv"
    user_buffer = StringIO()
    user_df.to_csv(user_buffer, index=False)
    user_content = user_buffer.getvalue()
    s3.put_object(Bucket=Bucket, Key=user_key, Body=user_content)

    # Move processed files
    for key in keys:
        copy_source = {'Bucket': Bucket, 'Key': key}
        s3.copy_object(CopySource=copy_source, Bucket=Bucket, Key=key.replace("toprocess", "processed"))
        s3.delete_object(Bucket=Bucket, Key=key)

    return "success"
