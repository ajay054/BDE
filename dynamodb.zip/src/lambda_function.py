import boto3

# Replace these values with your own
table_name = 'dtable'
key_schema = [
    {'AttributeName': 'Id', 'KeyType': 'HASH'},
    {'AttributeName': 'Timestamp', 'KeyType': 'RANGE'}
]
attribute_definitions = [
    {'AttributeName': 'Id', 'AttributeType': 'S'},
       {'AttributeName': 'Timestamp', 'AttributeType': 'S'}, {'AttributeName': 'Value', 'AttributeType': 'N'}
]
provisioned_throughput = {'ReadCapacityUnits': 2, 'WriteCapacityUnits': 2}
region = 'eu-north-1'

# Create DynamoDB client
dynamodb = boto3.client('dynamodb', region_name=region)

# Create the table
response = dynamodb.create_table(
    TableName=table_name,
    KeySchema=key_schema,
    AttributeDefinitions=attribute_definitions,
    ProvisionedThroughput=provisioned_throughput
)

# Wait for the table to be created before trying to put items
dynamodb.get_waiter('table_exists').wait(TableName=table_name)

# Now, you can put items into the table
item_id = '1'
value = 42 
timestamp = '2023-11-24T12:00:00Z'  

# Put item into the table
dynamodb.put_item(
    TableName=table_name,
    Item={
        'Id': {'S': item_id},
              'Timestamp': {'S': timestamp},  'Value': {'N': str(value)},
    }
)

print(f"Item with Id={item_id} added to the table {table_name}")