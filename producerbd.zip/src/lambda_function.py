import boto3
import json
import random
import string
import datetime

def generate_random_data():
    # Generate a random string of length 8
    random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))

    # Generate a random number
    random_number = 2604

    # Generate a timestamp
    timestamp = datetime.datetime.utcnow().isoformat()

    # Create a JSON payload
    data = {
        'id': random_string,
        'value': random_number,
        'email': timestamp
    }

    return json.dumps(data).encode('utf-8')

def lambda_handler(event, context):
    # Specify your Kinesis Data Stream name
    stream_name = 'topic123'

    # Create a Kinesis client
    kinesis_client = boto3.client('kinesis')

    # Generate random data
    for _ in range(2):
        data = generate_random_data()
    
        # Put the data record to the Kinesis stream
        response = kinesis_client.put_record(
            StreamName=stream_name,
            Data=data,
            PartitionKey='id'  # You can customize the partition key

    
        )
    
        print(f"Record sent to Kinesis Stream with sequence number: {response['SequenceNumber']}")

    return {
        'statusCode': 200,
        'body': json.dumps('Data sent to Kinesis Stream successfully!')
    }